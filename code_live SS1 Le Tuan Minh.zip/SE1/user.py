from readFile import *
from books import *

users = {}


for i in range(0,len(lines),3):
    if not(users.__contains__(lines[i])):
        users[lines[i]]=[]

# for user in users:
#     for book in range(len(books)):
#         users[user].append("0")
# print(user)

# def loopForRating():
#     ratingList = []
#
#     for i in range(0,len(books)):
#         for file_books in range(1,len(lines),3):
#             if(lines[file_books] == books[i]):
#                 for key in users:
#                     if(key == lines[file_books-1] and not ratedBook[key].__contains__(lines[file_books]) ):
#                         users[key].append(lines[file_books+1])
#                         ratedBook[key].append(lines[file_books])
#                         print(lines[file_books])
#                         print(users)
#                         print(ratedBook)
#                     elif(not key == lines[file_books-1]  and not ratedBook[key].__contains__(lines[file_books])):
#                         users[key].append("0")
#                         ratedBook[key].append(lines[file_books])






