from readFile import *
from user import *

books = []
for i in range(1,len(lines),3):
    if not(books.__contains__(lines[i])):
        books.append(lines[i])

for user in users:
    for book in range(len(books)):
        users[user].append("0")
def findIndex(book):
    for i in range(len(books)):
        if(books[i]==book):
            return i
def rating():
    for index in range(0, len(lines),3):
        book = lines[index+1]
        bookIndex = findIndex(book)
        users[lines[index]][bookIndex]=lines[index+2]

