lines = []
with open('./SS1/ratings-small.txt') as f:
    lines = [line.rstrip() for line in f]
