from readFile import *
from books import *
def averages():
    book_scores = {}
    for book in books:
        bookScore = 0
        count = 0
        for i in range(1, len(lines), 3):
            if(lines[i]==book and lines[i+1] != 0):
                bookScore  = bookScore + int(lines[i+1])
                count += 1
                book_scores[book]=(bookScore/count)

    return dictSort(book_scores)

def recommendation():
    user_input = input("User ?")
    if user_input in users:
        print(user_input)
    else:
        print(" user 0.000000not found")
def dictSort(diction):
    return dict(sorted(diction.items(), key=lambda item: item[1]))
print()

def main():
    print("Welcome to the CSC110 Book Recommender. Type the word in the \n "
          "left column to do the ction on the right. \n"
          "recommend : recommend books for a particular user \n"
          "averages : output the average ratings of all books in the system \n"
          "quit : exit the program\n"
          )
    user_input = input("next task ?")
    if(user_input.lower() == "averages"):
        sortedDict = averages()
        s = ""
        for key in sortedDict:
            strValue = str(sortedDict[key])
            s += key + "\t" + strValue + "\n"
        print(s)
    if(user_input.lower() == "recommendation"):
        recommendation()

main()

